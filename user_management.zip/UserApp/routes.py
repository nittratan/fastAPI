from fastapi import APIRouter, HTTPException, Depends
from Model.user_model import User
from Config.db import db

router = APIRouter()

@router.post("/users/")
def create_user(user: User):
    if db.users.find_one({"email": user.email}):
        raise HTTPException(status_code=400, detail="Email already exists")
    db.users.insert_one(user.dict())
    return {"message": "User created successfully"}

@router.get("/users/{username}")
def get_user(username: str):
    user = db.users.find_one({"username": username}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user
