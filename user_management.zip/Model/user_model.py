from pydantic import BaseModel, EmailStr

class User(BaseModel):
    username: str
    email: EmailStr
    name: str
    mobile_number: str
    age: int
    city: str
