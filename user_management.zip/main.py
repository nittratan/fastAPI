from fastapi import FastAPI
from UserApp.routes import router
import logging

app = FastAPI()

# Logging configuration
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

app.include_router(router)

@app.get("/")
def home():
    return {"message": "User Management API is running"}
